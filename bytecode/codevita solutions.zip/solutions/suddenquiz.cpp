#include<stdio.h>
static int a[100005];
static int begin[100005];
static int end[100005];
static int vis[100005];
static int in[100005];
int dfs(int i)
{
 vis[i]=1;
 if(!vis[a[i]]) return dfs(a[i]);
 else return i;
}
int main()
{
 int ans=0,i,j,n;
 scanf("%d",&n);
 for(i=1;i<=n;i++)
  {scanf("%d",&a[i]);in[a[i]]=1;}
 //counting connected components using root node(student to whom no one informs)
 for(i=1;i<=n;i++)
  if(in[i]==0)
  {
   begin[ans]=i;
   end[ans++]=dfs(i);
  }
 int inicon=ans; //inicon->seperate connected components that don't form cycle 
 //counting connected components that form a cycle
 for(i=1;i<=n;i++)
  if(vis[i]==0)
  {
   begin[ans]=i;
   end[ans++]=dfs(i);
  }
 if(inicon==0&&ans==1) printf("0");
 else printf("%d",ans);
 return 0;
}
