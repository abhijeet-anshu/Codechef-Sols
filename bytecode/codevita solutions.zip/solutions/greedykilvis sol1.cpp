#include<stdio.h>
#include<ctime>
#include<iostream>
using namespace std;
int main()
{
    int t,i;
    char a[65];
    unsigned long long int P,c;
    clock_t tStart = clock();
    scanf("%d",&t);
    while(t--)
    {
              c=0;
              scanf("%llu",&P);
              scanf("%s",a);
              for(i=0;a[i]!=0;i++)
              if(a[i]=='1')c++;
              printf("%llu\n",P-c);
    }
    //cout<<(double)(clock() - tStart)/CLOCKS_PER_SEC<<endl;
    return 0;
}
    
