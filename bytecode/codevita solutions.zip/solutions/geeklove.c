#include<stdio.h>
#include<ctime>
#include<iostream>
using namespace std;
int scan()
{
int t=0;
char c;
c=getchar_unlocked();
while(c<'0' || c>'9')
c=getchar_unlocked();
while(c>='0' && c<='9')
{
t=(t<<3)+(t<<1)+c-'0';
c=getchar_unlocked();
}
return t;
}   

void fun(int A[103][103],int n,int m,int i,int j,int P[])
{
   int k=A[i][j];
   if((i-1>=0&&i-1<n) && (j-1>=0&&j-1<m))
   {
       if(A[i-1][j-1]==k)
       {
         P[k]++;
       }
   }
   if((i-1>=0&&i-1<n) && (j>=0&&j<m))
   {
       if(A[i-1][j]==k)
       {
         P[k]++;
       }
   }
   if((i-1>=0&&i-1<n) && (j+1>=0&&j+1<m))
   {
       if(A[i-1][j+1]==k)
       {
         P[k]++;
       }
   }
   if((i>=0&&i<n) && (j-1>=0&&j-1<m))
   {
       if(A[i][j-1]==k)
       {
         P[k]++;
       }
   }
   if((i>=0&&i<n) && (j+1>=0&&j+1<m))
   {
       if(A[i][j+1]==k)
       {
         P[k]++;
       }
   }
   if((i+1>=0&&i+1<n) && (j-1>=0&&j-1<m))
   {
       if(A[i+1][j-1]==k)
       {
         P[k]++;
       }
   }
   if((i+1>=0&&i+1<n) && (j>=0&&j<m))
   {
       if(A[i+1][j]==k)
       {
         P[k]++;
       }
   }
   if((i+1>=0&&i+1<n) && (j+1>=0&&j+1<m))
   {
       if(A[i+1][j+1]==k)
       {
         P[k]++;
       }
   }
  return ; 
}




     
int main()
{
  int t;
  int A[103][103]={0};
  int P[103];
  int flag[103];
  int i,j,n,count,m;
  clock_t tStart = clock();
  t=scan();
  while(t--)
  {
     count=0;
     for(i=0;i<=102;i++)
     {
       P[i]=0;
       flag[i]=0;
       for(j=0;j<=102;j++)
        A[i][j]=0;
     }

     n=scan();
     m=scan();
     
     for(i=0;i<n;i++)
     {
       for(j=0;j<m;j++)
       {  
         scanf("%d",A[i]+j);
       }
     }
     for(i=0;i<n;i++)
     {
       for(j=0;j<m;j++)
       {
         if(A[i][j]==-1) continue;
         else if(flag[A[i][j]]==1) continue;
         else{
            fun(A,n,m,i,j,P);
           // printf("A[%d][%d]=%d(%d)\n",i,j,P[A[i][j]],A[i][j]);
           if(P[A[i][j]]>=1)
           {
              flag[A[i][j]]=1;
           }
         P[A[i][j]]=0;
        }
      }
     }
     //for(i=0;i<n;i++) printf("%d\n",flag[i]);
     for(i=0;i<103;i++)
     {
       if(flag[i]==1)  count++;
     }
     printf("%d\n",count);
  }
  //cout<<(double)(clock() - tStart)/CLOCKS_PER_SEC<<endl;
  return 0;
}
     
