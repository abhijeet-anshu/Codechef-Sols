#include<cstdio>
#include<iostream>
#include<algorithm>
#include<ctime>
using namespace std;
#define ll long long

int main()
{
   ll n,m,t,num,q,t_gcd;
   clock_t tStart = clock();
   cin>>t;
   
   while(t--)
   {
        cin>>n>>m;
        cin>>q;
        while(q--)
        {
			cin>>num;
			if(num>n&&num>m) cout<<"NO\n";
			else{
			    t_gcd=__gcd(n,m);
			    if(num%t_gcd==0) cout<<"YES\n";
			    else cout<<"NO\n";
			}
		}
	}
	//cout<<(double)(clock() - tStart)/CLOCKS_PER_SEC<<endl;
	return 0;
}
