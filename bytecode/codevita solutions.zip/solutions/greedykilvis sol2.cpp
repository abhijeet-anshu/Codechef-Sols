#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctime>
#include<iostream>
using namespace std;
int a[100001];
int main()
{
    int i,t;
    unsigned long long int n,k,sum;
    char c[65];
    clock_t tStart = clock();
    scanf("%d",&t);
    while(t--)
    {
    scanf("%llu",&n);
    scanf("%s",c);
    sum=0;              
    for(k=2;k<=n;k*=2)
    sum=sum+n/k;
    printf("%llu\n",sum);
    }
    cout<<(double)(clock() - tStart)/CLOCKS_PER_SEC<<endl;
    return 0;
}               
